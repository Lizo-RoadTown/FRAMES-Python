# Archive Index

Contains deprecated, superseded, or experimental documents.

## Rules
- Nothing in /archive is active
- Agents cannot write to /archive unless ordered
- Each archived file must have a reason for deprecation

Archive is for historical reference only.
